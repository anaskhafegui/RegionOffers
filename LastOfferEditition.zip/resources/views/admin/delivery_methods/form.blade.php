@include('admin.layouts.partials.validation-errors')
@include('flash::message')

{!! Field::text('name' , 'الاسم') !!}


